# Panda TV — 0.1.0 beta

Bağımsız Android TV uygulaması. iPhone kamerasının görüntüsünü ve mikrofon sesini QR üzerinden TV’ye gönderir. TV, telefon ve kurulum ekranı retro ceviz/krem/pirinç renklerindedir. TV’de onaylanan retro ahşap çerçeve kullanılır. Panda TV logosu görüntünün sol üstünde sabittir ve çerçevesiz tam ekran modunda da kalır. Logo TV arayüzü katmanıdır; telefonun kamera verisine işlenmez. Teknik proje/paket adı KolayCanliYayin olarak korunmuştur.

**Bu ZIP kaynak koddur; APK’yı GitHub Actions üretir. Henüz gerçek iPhone + Android TV üzerinde doğrulanmış bir ürün sürümü değildir.**

## Önemli: APK tek başına yeterli değil

Safari kamera/mikrofon için güvenilir HTTPS ister. Bu nedenle bir HTTPS web servisi gerekir. Aynı servis hem telefon sayfasını hem TV sayfasını hem de eşleştirmeyi sunar. GitHub Actions yalnızca derleme yapar, sürekli çalışan sunucu değildir. GitHub Pages bu Node sunucusunu çalıştıramaz.

Bu sürümde STUN/TURN yoktur. Yalnız özel yerel IP ve mDNS host ICE adayları aktarılır. İnternet sayfa ve eşleştirme için kullanılır; medya aktarım sunucusu yoktur. Misafir ağı/istemci yalıtımı/mDNS engeli varsa bağlantı başarısız olabilir. Bu bir aynı-SSID doğrulaması değildir; yönlendirilmiş özel ağlar/VPN davranışı farklı olabilir. Uzaktan yayın desteklenmez.

## 1. GitHub’a yükle

1. Yeni repo oluştur; tercihen özel tut.
2. ZIP’i aç. İçindeki **KolayCanliYayin klasörünün içeriğini** repo köküne yükle.
3. Repo kökünde `settings.gradle.kts`, `package.json`, `render.yaml` ve `.github/workflows/build-apk.yml` bulunmalı. `.github` gizli klasörünü atlama.
4. Actions → **Build APK** çalışır. Gerekirse Actions kullanımını etkinleştir.
5. Yeşil sonuç → Artifacts → **KolayCanliYayin-debug-APK** → içindeki `app-debug.apk` dosyasını TV’ye kur.

## 2. HTTPS servisini bir kez yayınla

Hazır `render.yaml` dosyası aynı GitHub reposunu Render Blueprint ile yayınlamak içindir. Başka bir Node 22+ HTTPS sağlayıcısı da kullanılabilir. Bu işlem kullanıcı hesabından yapılmalıdır; bu ZIP herhangi bir servis açmaz, ücretli kaynak oluşturmaz.

Render örneği:

1. Render hesabında New → Blueprint ile bu GitHub reposunu seç.
2. Oluşturulacak web servisinin gerçek adresini belirle (örn. `https://kolay-canli-yayin-xxxx.onrender.com`).
3. **PUBLIC_URL** ortam değişkenine bu gerçek adresi, yol eklemeden yaz. Yanlış adres origin kontrolünden dolayı bağlantıyı engeller. Adres ancak ilk dağıtımdan sonra belli olduysa ortam değişkenini güncelle ve yeniden dağıt.
4. Build command: `npm run check`; start command: `npm start`; health check: `/health`. Harici npm bağımlılığı yoktur.
5. `https://GERCEK-ADRES/health` JSON olarak `{"ok":true}` dönmeli.

Blueprint ücretsiz plan ister; sağlayıcının güncel kullanılabilirliğini/koşullarını hesabında kontrol et. Ücretsiz servis uykuya girerse ilk bağlantı gecikebilir. Tek sunucu örneği kullan: odalar bellektedir; yeniden başlatmada QR’lar geçersiz olur. Çok örnekli üretim ölçeği bu beta kapsamı dışındadır.

## 3. TV’ye sunucu adresini ver

En kolay: APK ilk açıldığında HTTPS ana adresini yaz → Kaydet. Bu ayar TV’de saklanır; her seferinde gerekmez.

Adres APK’da otomatik gelsin istersen GitHub repo → Settings → Secrets and variables → Actions → **Variables** → `APP_URL` ekle. Değer, PUBLIC_URL ile aynı HTTPS ana adres olsun. Sonra Actions → Build APK → Run workflow. Bu değişken gizli değildir.

## 4. Yayını dene

1. Telefon ve TV’yi aynı normal Wi-Fi ağına bağla (misafir ağı değil).
2. TV uygulamasında QR çıkmalı; iPhone kamerasıyla okut.
3. Safari’de **Kamerayı aç ve bağlan**; kamera ve mikrofon izinlerini ver.
4. TV kumandasıyla **Kabul et** seç.
5. Ön/arka kamera, mikrofon aç/kapat ve Yayını bitir telefon sayfasındadır.
6. TV’de **Tam ekran** çerçeveyi gizler. **Yayını bitir / Yeni QR** eski oturumu kapatır.
7. TV’de Menü tuşu ayarları açar. Geri tuşu çıkış onayı gösterir.

QR 5 dakika geçerli ve tek telefonluk. Bağlantı koparsa otomatik yeniden eşleştirme yerine yeni QR oluştur. Uygulama arka plana gidince yayın durur; bu sürüm arka planda alıcı değildir. Safari açık, telefon ekranı uyanık kalmalıdır. Ekran uyanık tutma API’si desteklenirse istenir; telefon kilitlenince arka plan kamera garantisi yoktur.

## APK / cihaz gereksinimleri

- Android TV 8.0+ (API 26); güncel Android System WebView. İlk prototipte native Kotlin kabuğun içinde HTTPS WebRTC alıcısı kullanılır; native libwebrtc SDK değildir.
- Güncel iPhone Safari; kamera ve mikrofon izinleri.
- 720p/30 FPS bir istek/hedeftir, garantili çıktı değildir; cihaz ve bağlantıya göre değişebilir.
- Derleme: JDK 17, Gradle 8.11.1, AGP 8.9.2, Kotlin 2.1.10, Android SDK 35.
- Gradle wrapper pakete dahil değildir; Actions `setup-gradle` ile doğru Gradle sürümünü kurar. Yerelde `gradle :app:assembleDebug` kullanılır.
- Android uygulaması kamera/mikrofon izni istemez; TV yalnız alıcıdır.

## Kalıcı release APK (isteğe bağlı)

Debug APK test içindir. CI debug imzası farklı çalışmalarda değişebilir: sonraki beta APK’yı kurmadan eski debug uygulamasını kaldırmak gerekebilir; bu işlem sunucu adresi ayarını siler.

Herkese dağıtmak için kendine ait kalıcı keystore oluştur, güvenli yedeğini al ve repo Actions Secrets alanına koy:

- `KEYSTORE_B64`: keystore dosyasının Base64 değeri
- `KEYSTORE_PASSWORD`
- `KEY_ALIAS`
- `KEY_PASSWORD`

Workflow bunlar sağlanınca ayrıca **KolayCanliYayin-release-APK** üretir. Keystore repoya/ZIP’e koyulmaz. `versionCode`, GitHub run number’dan gelir; repo değiştirilirse kurulu sürümden büyük tutulmalıdır. Debug paket adı `com.kolaycanliyayin.tv.debug`, release `com.kolaycanliyayin.tv` olduğundan yan yana kurulabilir.

## Tasarım ve güvenlik

- Onaylanan retro PNG, `web/frame.png`; canlı video alttaki boş alana yerleştirilir. PNG’deki kırmızı lamba dekoratiftir; gerçek yayın durumu ekran içindeki dinamik CANLI etiketidir.
- Kayıt/ses dosyası yükleme yok. Sunucu yalnız SDP/ICE ve oturum mesajlarını bellekte tutar; internet üzerinden bağlantı metaverisi geçer.
- Ayrı, rastgele 192-bit alıcı/gönderici token’ları; gönderici anahtarı URL fragment’ında taşınır ve sayfa açılınca adres çubuğundan kaldırılır.
- TV onayı olmadan SDP alışverişi engellenir; gönderen/alıcı rolleri ayrıdır.
- Origin kontrolü, JSON boyut sınırı, oda/mesaj kuyruğu sınırı, CSP ve referrer kapatma vardır.
- Güncel tarayıcı ve sağlayıcı TLS güvenliği gerekir. Bu beta bağımsız güvenlik denetiminden geçmemiştir.

## Yerel testler

`npm run check` ve `npm test` (Node 22+). Ek npm paketi kurulmaz.

Sunucu yerelde `npm start` ile 3000 portunda açılır. `http://localhost:3000/tv` bilgisayar tarayıcı testine yarar; telefonun `http://192.168...` sayfası kamera için uygun değildir. Telefon testi gerçek HTTPS dağıtımında yapılır.

## Test durumu

Sunucu ve protokol testleri teslim notunda belirtilir. Bu ortamda Android SDK ve gerçek TV/iPhone yok; APK derlemesi ve fiziksel cihaz testi GitHub Actions + kullanıcı cihazında yapılmalıdır. Yeşil Actions sonucu WebRTC’nin her TV/modemde çalıştığını kanıtlamaz.

Elle doğrula: 720p/1080p TV, QR okunabilirliği, D-pad ile Kabul/Reddet, mikrofon sesi, ön/arka kamera, tam ekran, izin reddi, 35 sn bağlantı zaman aşımı, Safari kilitlenmesi, TV arka plana geçişi, kopma sonrası yeni QR, sunucu yeniden başlatma, aynı QR’a ikinci telefon, aynı odada ses yankısı.

Kaynaklar: https://webkit.org/blog/7763/a-closer-look-into-webrtc/ • https://webrtc.org/getting-started/peer-connections • https://developer.android.com/reference/android/webkit/WebSettings • https://render.com/docs/blueprint-spec
