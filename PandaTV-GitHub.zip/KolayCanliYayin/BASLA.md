# Panda TV — hızlı başlangıç

## ZIP → GitHub → APK

1. ZIP’i aç; `KolayCanliYayin` klasörünün **içindekileri** yeni GitHub repo köküne yükle. `.github` klasörü de gitmeli.
2. **Actions → Build APK** çalışmasını aç.
3. İşlem yeşil bitince **Artifacts → KolayCanliYayin-debug-APK** dosyasını indir.
4. İçindeki `app-debug.apk` dosyasını TV’ye kur.

## Yayın için bir kere yapılacak

APK tek başına kamera yayını başlatamaz: güvenli HTTPS arayüzü ve eşleştirme servisi gerekir. Bunların kodu da ZIP içindedir; GitHub sürekli sunucu çalıştırmaz.

`README.md` dosyasındaki **HTTPS servisini bir kez yayınla** adımını uygula. Hazır `render.yaml`, GitHub reposundan dağıtıma yardımcı olur. Servis açıldıktan sonra HTTPS adresini TV’nin ilk kurulum ekranına bir kez yaz.

Sonra: aynı Wi-Fi → TV’de QR → iPhone’da kamera/mikrofon izni → TV’de Kabul et → canlı yayın.

## Bu pakette neler var?

- Panda TV isimli Android TV APK projesi
- Retro telefon yayın ekranı ve retro TV çerçevesi
- Görüntünün sol üstünde sabit Panda TV logosu; tam ekranda da kalır
- Ön/arka kamera, mikrofon kapatma ve yayın bitirme
- Tek kullanımlık süreli QR + TV onayı
- Node.js HTTPS sağlayıcısına uygun eşleştirme sunucusu
- GitHub Actions derleme ve otomatik testleri

## Gerçek durum

Kaynak kod ve otomatik sunucu/protokol testleri hazırdır. APK burada derlenmedi; GitHub Actions derleyecek. Gerçek iPhone/TV yayını cihazlarda test edilmelidir. Android TV 8+ ve güncel Android System WebView gerekir.
