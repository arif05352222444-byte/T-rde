import { $, Link, makePeer, lanSdp, isLanCandidate, friendly } from './common.mjs';
const params = new URLSearchParams(location.hash.slice(1));
const id = params.get('room'), token = params.get('key');
// Tokens never go into HTTP request paths or Referer headers.
history.replaceState(null, '', location.pathname);
let stream, pc, link, pending = [], facing = 'environment', wake, timer, stopped = false;
const status = text => { $('status').textContent = text; };
if (id && token && window.isSecureContext && navigator.mediaDevices && window.RTCPeerConnection) {
  $('start').disabled = false; status('Hazır. Kameranı aç; TV’deki kişi yayını onaylasın.');
} else if (id && token) status('Güvenli HTTPS bağlantısı ve güncel Safari gerekiyor.');
async function holdScreen() { try { wake = await navigator.wakeLock?.request('screen'); } catch {} }
async function finish(text, notify = true) {
  if (stopped) return; stopped = true;
  clearTimeout(timer); if (notify && link) link.send({ type: 'stop' }).catch(() => {});
  link?.close(); pc?.close(); stream?.getTracks().forEach(t => t.stop());
  await wake?.release().catch(() => {});
  $('preview').srcObject = null; $('live').hidden = true; $('previewHint').hidden = false;
  for (const k of ['start','flip','mute','stop']) $(k).disabled = true;
  status(text);
}
async function message(m) {
  if (m.type === 'accept') {
    clearTimeout(timer); status('TV onayladı. Yerel bağlantı kuruluyor…');
    pc = makePeer(link, state => {
      if (state === 'connected') { clearTimeout(timer); $('live').hidden = false; status('Canlı yayındasın.'); }
      if (state === 'disconnected') status('Bağlantı zayıfladı; yeniden bağlanmaya çalışıyor…');
      if (state === 'failed') finish('Yerel bağlantı kurulamadı. Aynı Wi-Fi’yı, misafir ağı ve cihaz yalıtımı ayarlarını kontrol et.');
    });
    stream.getTracks().forEach(track => pc.addTrack(track, stream));
    const offer = await pc.createOffer();
    // Queue candidate requests behind the offer to avoid a description race.
    await link.send({ type: 'offer', sdp: lanSdp(offer.sdp) });
    await pc.setLocalDescription(offer);
    timer = setTimeout(() => finish('Bağlantı zaman aşımına uğradı. Aynı ağda olduğunuzu kontrol edip yeni QR ile dene.'), 35000);
  } else if (m.type === 'answer' && pc) {
    await pc.setRemoteDescription({ type: 'answer', sdp: lanSdp(m.sdp) });
    for (const c of pending) await pc.addIceCandidate(c); pending = [];
  } else if (m.type === 'candidate' && isLanCandidate(m.candidate.candidate)) {
    if (pc?.remoteDescription) await pc.addIceCandidate(m.candidate); else pending.push(m.candidate);
  } else if (m.type === 'reject' || m.type === 'stop') await finish('TV yayını sonlandırdı. Yeniden başlamak için yeni QR okut.', false);
}
$('start').onclick = async () => {
  $('start').disabled = true; stopped = false; status('Kamera ve mikrofon izni bekleniyor…');
  try {
    stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: facing }, width: { ideal: 1280 }, height: { ideal: 720 }, frameRate: { ideal: 30, max: 30 } }, audio: { echoCancellation: true, noiseSuppression: true } });
    $('preview').srcObject = stream; $('previewHint').hidden = true;
    for (const k of ['flip','mute','stop']) $(k).disabled = false;
    stream.getVideoTracks()[0].onended = () => finish('Kamera kapandı. TV’den yeni QR ile tekrar bağlan.');
    link = new Link(id, 'sender', token, message, e => finish(friendly(e), false));
    await link.request('join'); status('TV’de “Kabul et” seçilmesini bekliyor…'); link.poll(); holdScreen();
    timer = setTimeout(() => finish('TV onayı gelmedi. Yeni QR ile tekrar dene.'), 120000);
  } catch (e) { await finish(friendly(e)); }
};
$('stop').onclick = () => finish('Yayın bitti. Yeni yayın için TV’den yeni QR oluştur.');
$('mute').onclick = () => {
  const audio = stream?.getAudioTracks()[0]; if (!audio) return;
  audio.enabled = !audio.enabled; $('mute').textContent = audio.enabled ? 'Mikrofonu kapat' : 'Mikrofonu aç';
};
$('flip').onclick = async () => {
  $('flip').disabled = true;
  const old = stream.getVideoTracks()[0]; old.onended = null; old.stop();
  facing = facing === 'environment' ? 'user' : 'environment';
  try {
    const replacement = await navigator.mediaDevices.getUserMedia({ video: { facingMode: { ideal: facing }, width: { ideal: 1280 }, height: { ideal: 720 } }, audio: false });
    if (stopped) { replacement.getTracks().forEach(t => t.stop()); return; }
    const track = replacement.getVideoTracks()[0]; stream.removeTrack(old); stream.addTrack(track);
    track.onended = () => finish('Kamera kapandı. Yeni QR ile tekrar bağlan.');
    const sender = pc?.getSenders().find(s => s.track?.kind === 'video'); if (sender) await sender.replaceTrack(track);
    $('preview').srcObject = stream;
  } catch (e) { await finish(friendly(e)); }
  $('flip').disabled = stopped;
};
document.addEventListener('visibilitychange', () => { if (!document.hidden && stream && !stopped) holdScreen(); });
window.addEventListener('pagehide', () => { stream?.getTracks().forEach(t => t.stop()); pc?.close(); link?.close(); });
