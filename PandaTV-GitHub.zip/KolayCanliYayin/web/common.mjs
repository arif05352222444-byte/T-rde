export const $ = id => document.getElementById(id);
export function isLanCandidate(value) {
  const parts = value.trim().split(/\s+/); const i = parts.indexOf('typ');
  if (i < 0 || parts[i + 1] !== 'host') return false;
  const host = (parts[4] || '').toLowerCase();
  if (host.endsWith('.local')) return true;
  if (/^(fc|fd)[0-9a-f]{2}:/.test(host) || host.startsWith('fe80:')) return true;
  const p = host.split('.').map(Number);
  if (p.length !== 4 || p.some(v => !Number.isInteger(v) || v < 0 || v > 255)) return false;
  return p[0] === 10 || (p[0] === 192 && p[1] === 168) || (p[0] === 172 && p[1] >= 16 && p[1] <= 31);
}
export function lanSdp(sdp) {
  return sdp.split('\r\n').filter(line => !line.startsWith('a=candidate:') || isLanCandidate(line.slice(2))).join('\r\n');
}
export async function api(path, body = {}, token = '') {
  const response = await fetch('/api/' + path, { method: 'POST', credentials: 'omit', cache: 'no-store',
    headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) }, body: JSON.stringify(body), signal: AbortSignal.timeout(12000) });
  const data = await response.json(); if (!response.ok) throw Error(data.error || 'connection'); return data;
}
export class Link {
  constructor(id, role, token, onMessage, onError) { Object.assign(this, { id, role, token, onMessage, onError }); this.closed = false; }
  request(path, extra = {}) { return api(path, { id: this.id, role: this.role, ...extra }, this.token); }
  send(message) { return this.request('signal', { message }); }
  async poll() {
    let failures = 0;
    while (!this.closed) {
      let messages = [];
      try {
        messages = (await this.request('poll')).messages; failures = 0;
      } catch (e) {
        if (e.message === 'unauthorized' || ++failures >= 4) { this.closed = true; this.onError(e); break; }
      }
      for (const m of messages) {
        if (this.closed) break;
        try { await this.onMessage(m); }
        catch (e) { this.closed = true; this.onError(e); return; }
      }
      await new Promise(resolve => setTimeout(resolve, 800));
    }
  }
  close() { this.closed = true; }
}
export function makePeer(link, onState, onTrack) {
  const pc = new RTCPeerConnection({ iceServers: [], iceCandidatePoolSize: 0 });
  pc.onicecandidate = event => {
    if (event.candidate && isLanCandidate(event.candidate.candidate)) link.send({ type: 'candidate', candidate: event.candidate.toJSON() }).catch(() => onState('failed'));
  };
  pc.onconnectionstatechange = () => onState(pc.connectionState);
  if (onTrack) pc.ontrack = onTrack;
  return pc;
}
export function friendly(e) {
  return ({ NotAllowedError: 'Kamera ve mikrofon izni verilmedi. Safari site izinlerini kontrol et.', NotFoundError: 'Kamera veya mikrofon bulunamadı.', NotReadableError: 'Kamera başka bir uygulamada kullanılıyor olabilir.',
    unauthorized: 'Bağlantının süresi doldu. TV’den yeni QR oluştur.', 'already-joined': 'Bu QR kullanıldı. TV’den yeni QR oluştur.', 'not-approved': 'TV’den yayın izni bekleniyor.', capacity: 'Sunucu dolu. Biraz sonra tekrar dene.' })[e.name] || ({ unauthorized: 'Bağlantının süresi doldu. TV’den yeni QR oluştur.', 'already-joined': 'Bu QR kullanıldı. TV’den yeni QR oluştur.' })[e.message] || 'Bağlantı kurulamadı. İnterneti kontrol et ve TV’den yeni QR oluştur.';
}
