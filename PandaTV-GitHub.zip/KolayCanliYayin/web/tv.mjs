import { $, api, Link, makePeer, lanSdp, isLanCandidate, friendly } from './common.mjs';
let link, pc, pending = [], expiryTimer, connectTimer, generation = 0, creating = false;
const status = text => { $('status').textContent = text; };
function clearPeer() { clearTimeout(connectTimer); pc?.close(); pc = null; pending = []; $('remote').srcObject = null; $('badge').hidden = true; }
async function endRoom() {
  clearTimeout(expiryTimer); clearPeer();
  if (link) { const old = link; link = null; old.close(); await old.send({ type: 'stop' }).catch(() => {}); await old.request('delete').catch(() => {}); }
}
async function createRoom() {
  if (creating) return;
  creating = true;
  const gen = ++generation; $('new').disabled = true;
  await endRoom(); $('waiting').hidden = false; $('approval').hidden = true; $('qr').hidden = true; status('Yeni bağlantı hazırlanıyor…');
  try {
    if (!window.RTCPeerConnection) throw Error('webview');
    const room = await api('create'); if (gen !== generation) { creating = false; return; }
    link = new Link(room.id, 'receiver', room.receiver, onMessage, e => { clearPeer(); $('waiting').hidden = false; $('qr').hidden = true; status(friendly(e)); });
    const url = location.origin + '/#' + new URLSearchParams({ room: room.id, key: room.sender });
    if (window.TVBridge?.qr) { $('qr').src = window.TVBridge.qr(url); $('qr').hidden = false; status('QR’ı iPhone kameranla okut. 5 dakika geçerli.'); }
    else { status('TV APK’sında açıldığında QR gösterilir. Tarayıcı testi için bağlantı: ' + url); }
    link.poll(); expiryTimer = setTimeout(() => { endRoom(); $('qr').hidden = true; status('QR süresi doldu. Yeni QR oluştur.'); }, 300000);
  } catch (e) { status(e.message === 'webview' ? 'Android System WebView güncellemesi gerekiyor.' : friendly(e)); }
  $('new').disabled = false; creating = false;
}
async function onMessage(m) {
  if (m.type === 'join') { $('qr').hidden = true; status('Bir telefon yayın göndermek istiyor. İzin veriyor musun?'); $('approval').hidden = false; $('accept').focus(); }
  else if (m.type === 'offer') {
    pc = makePeer(link, state => {
      if (state === 'connected') { clearTimeout(connectTimer); $('waiting').hidden = true; $('badge').hidden = false; $('full').focus(); }
      if (state === 'failed' || state === 'disconnected') { $('waiting').hidden = false; $('badge').hidden = true; status('Yerel bağlantı kesildi. Yeni QR ile tekrar bağlan.'); }
    }, event => { $('remote').srcObject = event.streams[0] || new MediaStream([event.track]); $('remote').play().catch(() => { status('Sesi açmak için OK tuşuna bas.'); }); });
    await pc.setRemoteDescription({ type: 'offer', sdp: lanSdp(m.sdp) });
    const answer = await pc.createAnswer(); await link.send({ type: 'answer', sdp: lanSdp(answer.sdp) }); await pc.setLocalDescription(answer);
    for (const c of pending) await pc.addIceCandidate(c); pending = [];
    connectTimer = setTimeout(() => { clearPeer(); $('waiting').hidden = false; status('Bağlantı kurulamadı. Aynı Wi-Fi ve cihaz yalıtımı ayarlarını kontrol et.'); }, 35000);
  } else if (m.type === 'candidate' && isLanCandidate(m.candidate.candidate)) {
    if (pc?.remoteDescription) await pc.addIceCandidate(m.candidate); else pending.push(m.candidate);
  } else if (m.type === 'stop') { clearPeer(); $('waiting').hidden = false; status('Telefondaki yayın sona erdi. Yeni QR oluştur.'); }
}
$('accept').onclick = async () => { $('approval').hidden = true; clearTimeout(expiryTimer); status('Telefon bağlanıyor…'); try { await link.send({ type: 'accept' }); } catch (e) { status(friendly(e)); } };
$('reject').onclick = async () => { await link?.send({ type: 'reject' }).catch(() => {}); await createRoom(); };
$('new').onclick = createRoom; $('end').onclick = createRoom;
$('full').onclick = () => { document.body.classList.toggle('full'); $('full').textContent = document.body.classList.contains('full') ? 'Çerçeveyi göster' : 'Tam ekran'; $('remote').play().catch(() => {}); };
$('settings').onclick = () => window.TVBridge?.settings();
document.addEventListener('keydown', event => {
  if (['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(event.key)) {
    event.preventDefault(); const buttons = [...document.querySelectorAll('button')].filter(b => !b.disabled && b.getClientRects().length);
    const current = buttons.indexOf(document.activeElement); const direction = ['ArrowLeft','ArrowUp'].includes(event.key) ? -1 : 1;
    buttons[(current + direction + buttons.length) % buttons.length]?.focus();
  }
});
window.stopLive = () => { generation++; endRoom(); };
window.addEventListener('pagehide', () => { link?.close(); clearPeer(); });
createRoom();
