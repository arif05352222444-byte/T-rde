import test from 'node:test';
import assert from 'node:assert/strict';
import { Rooms } from '../server/rooms.mjs';
import { isLanCandidate, lanSdp } from '../web/common.mjs';
test('room tokens are separate; access requires the correct role token', () => {
  const store = new Rooms(); const room = store.create();
  assert.notEqual(room.receiver, room.sender);
  assert.throws(() => store.auth(room.id, 'receiver', room.sender), /unauthorized/);
  assert.throws(() => store.auth(room.id, '__proto__', room.sender), /unauthorized/);
  assert.throws(() => store.auth(room.id, 'sender', 'é'.repeat(32)), /unauthorized/);
  assert.equal(store.auth(room.id, 'sender', room.sender).id, room.id);
});
test('single-use join and explicit TV approval before SDP', () => {
  const store = new Rooms(); const keys = store.create(); const room = store.auth(keys.id, 'receiver', keys.receiver);
  assert.throws(() => store.signal(room, 'sender', { type: 'offer', sdp: 'v=0' }), /not-approved/);
  store.join(room); assert.throws(() => store.join(room), /already-joined/);
  assert.deepEqual(store.poll(room, 'receiver'), [{ type: 'join' }]);
  store.signal(room, 'receiver', { type: 'accept' });
  store.signal(room, 'sender', { type: 'offer', sdp: 'v=0' });
  assert.deepEqual(store.poll(room, 'receiver'), [{ type: 'offer', sdp: 'v=0' }]);
  assert.equal(store.poll(room, 'sender')[0].type, 'accept');
});
test('expiration, capacity and signal validation', () => {
  let now = 0; const store = new Rooms({ now: () => now, max: 1 }); const key = store.create();
  assert.throws(() => store.create(), /capacity/); now = 300001;
  assert.throws(() => store.auth(key.id, 'sender', key.sender), /unauthorized/);
  const next = store.create(); const room = store.auth(next.id, 'receiver', next.receiver);
  store.join(room); store.signal(room, 'receiver', { type: 'accept' });
  assert.throws(() => store.signal(room, 'receiver', { type: 'offer', sdp: 'v=0' }), /wrong-role/);
  assert.throws(() => store.signal(room, 'sender', { type: 'candidate', candidate: {} }), /invalid-candidate/);
  assert.throws(() => store.signal(room, 'sender', { type: 'offer', sdp: 'x'.repeat(80001) }), /invalid-sdp/);
  for (let i = 1; i < 128; i++) store.push(room, 'receiver', { type: 'test' });
  assert.throws(() => store.push(room, 'receiver', {}), /queue-full/);
});
test('LAN-only ICE filtering rejects public, STUN and TURN candidates', () => {
  const candidate = (host, type = 'host') => `candidate:1 1 udp 123 ${host} 5000 typ ${type}`;
  for (const host of ['192.168.0.11','10.0.0.4','172.16.1.2','camera.local','fd12::1','fe80::1']) assert.equal(isLanCandidate(candidate(host)), true, host);
  for (const host of ['8.8.8.8','127.0.0.1','172.32.1.1','2001:4860::1','999.1.1.1']) assert.equal(isLanCandidate(candidate(host)), false, host);
  assert.equal(isLanCandidate(candidate('192.168.1.2','relay')), false);
  assert.equal(isLanCandidate(candidate('192.168.1.2','srflx')), false);
  assert.equal(lanSdp('v=0\r\na=' + candidate('8.8.8.8') + '\r\na=' + candidate('10.0.0.1') + '\r\n'), 'v=0\r\na=' + candidate('10.0.0.1') + '\r\n');
});
