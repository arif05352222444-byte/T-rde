import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
test('Panda TV brand is permanent inside the video screen, including full screen', async () => {
  const html = await readFile(new URL('../web/tv.html', import.meta.url), 'utf8');
  const css = await readFile(new URL('../web/style.css', import.meta.url), 'utf8');
  assert.match(html, /id="channel-logo"[^>]+panda-logo\.png/);
  assert.ok(html.indexOf('id="channel-logo"') < html.indexOf('</section>'));
  assert.match(css, /#channel-logo\s*\{[^}]*left:\s*4%/);
  assert.doesNotMatch(css, /\.full\s+#channel-logo\s*\{[^}]*display:\s*none/);
  for (const page of ['sender.html', 'tv.html']) {
    const source = await readFile(new URL('../web/' + page, import.meta.url), 'utf8');
    for (const [, name] of source.matchAll(/(?:src|href)="\/([^"#]+)"/g)) {
      assert.ok((await readFile(new URL('../web/' + name, import.meta.url))).length > 0, name);
    }
  }
});
