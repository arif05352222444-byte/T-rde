import test from 'node:test';
import assert from 'node:assert/strict';
import { createApp } from '../server/main.mjs';
test('HTTP pairing lifecycle, origin isolation, headers and static files', async () => {
  const server = createApp({ publicUrl: 'https://example.test' });
  await new Promise(resolve => server.listen(0, '127.0.0.1', resolve));
  const base = 'http://127.0.0.1:' + server.address().port;
  const post = (route, data = {}, token, origin = 'https://example.test') => fetch(base + '/api/' + route, { method: 'POST', headers: { Origin: origin, 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) }, body: JSON.stringify(data) });
  try {
    assert.equal((await fetch(base + '/health')).status, 200);
    for (const route of ['/', '/tv', '/common.mjs', '/sender.mjs', '/tv.mjs', '/style.css', '/frame.png', '/panda-logo.png']) {
      const response = await fetch(base + route); assert.equal(response.status, 200, route); assert.equal(response.headers.get('referrer-policy'), 'no-referrer'); await response.arrayBuffer();
    }
    assert.equal((await post('create', {}, null, 'https://evil.test')).status, 403);
    const created = await post('create'); assert.equal(created.status, 201); const room = await created.json();
    const sender = { id: room.id, role: 'sender' }, receiver = { id: room.id, role: 'receiver' };
    assert.equal((await post('poll', receiver, room.sender)).status, 401);
    assert.equal((await post('join', sender, room.sender)).status, 200);
    assert.equal((await post('join', sender, room.sender)).status, 409);
    let response = await post('poll', receiver, room.receiver); assert.equal((await response.json()).messages[0].type, 'join');
    assert.equal((await post('signal', { ...sender, message: { type: 'offer', sdp: 'v=0' } }, room.sender)).status, 400);
    assert.equal((await post('signal', { ...receiver, message: { type: 'accept' } }, room.receiver)).status, 200);
    assert.equal((await post('signal', { ...sender, message: { type: 'offer', sdp: 'v=0' } }, room.sender)).status, 200);
    assert.equal((await post('delete', receiver, room.receiver)).status, 200);
    assert.equal((await post('poll', sender, room.sender)).status, 401);
    assert.equal((await fetch(base + '/server/main.mjs')).status, 404);
  } finally { server.closeAllConnections(); await new Promise(resolve => server.close(resolve)); }
});
