package com.kolaycanliyayin.tv

import android.annotation.SuppressLint
import android.app.Activity
import android.app.AlertDialog
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.util.Base64
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ImageView
import android.widget.TextView
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.MultiFormatWriter
import java.io.ByteArrayOutputStream
import java.net.URI

class MainActivity : Activity() {
    private var browser: WebView? = null
    private var serverUrl = ""
    private var paused = false
    private val prefs by lazy { getSharedPreferences("live_settings", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        serverUrl = prefs.getString("server", BuildConfig.DEFAULT_SERVER_URL).orEmpty()
        if (validUrl(serverUrl) == null) showSettings() else openTv()
    }
    private fun validUrl(value: String): String? = try {
        val uri = URI(value.trim())
        if (uri.scheme != "https" || uri.host.isNullOrBlank() || uri.userInfo != null || uri.query != null || uri.fragment != null || (uri.path.isNotEmpty() && uri.path != "/")) null
        else "https://${uri.rawAuthority}"
    } catch (_: Exception) { null }

    private fun destroyBrowser() {
        browser?.apply { evaluateJavascript("window.stopLive && window.stopLive()", null); stopLoading(); loadUrl("about:blank"); removeJavascriptInterface("TVBridge"); destroy() }
        browser = null
    }
    private fun showSettings() {
        destroyBrowser()
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(56, 28, 56, 28); background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(67,43,28), Color.rgb(25,18,12))) }
        fun label(text: String, size: Float) = TextView(this).apply { this.text = text; textSize = size; setTextColor(Color.rgb(247,232,204)); setPadding(0, 8, 0, 12) }
        layout.addView(ImageView(this).apply { setImageResource(com.kolaycanliyayin.tv.R.drawable.panda_logo); contentDescription = "Panda TV"; adjustViewBounds = true }, LinearLayout.LayoutParams(180, 100))
        layout.addView(label("Panda TV • Yayın bağlantısı", 26f).apply { typeface = Typeface.create("serif", Typeface.BOLD) })
        layout.addView(label("ZIP’teki web sunucusunu HTTPS ile yayınladıktan sonra adresini yaz. Bu ayar bir kez yapılır. GitHub APP_URL değişkeni ayarlıysa otomatik gelir.", 16f))
        val input = EditText(this).apply { setSingleLine(true); inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI; hint = "https://sunucun.onrender.com"; setText(serverUrl); setTextColor(Color.WHITE); setHintTextColor(Color.GRAY) }
        layout.addView(input)
        val error = label("", 15f)
        layout.addView(Button(this).apply {
            text = "Kaydet ve TV’yi aç"
            setOnClickListener {
                val clean = validUrl(input.text.toString())
                if (clean == null) error.text = "Yalnızca geçerli HTTPS ana adresini yaz. Sonuna /tv ekleme."
                else { serverUrl = clean; prefs.edit().putString("server", clean).apply(); openTv() }
            }
        })
        layout.addView(error)
        layout.addView(label("Telefon ve TV aynı Wi-Fi’da olmalı. Güncel Android System WebView gerekir. Menü tuşu: ayarlar.", 14f))
        setContentView(layout)
    }
    @SuppressLint("SetJavaScriptEnabled")
    private fun openTv() {
        destroyBrowser()
        val view = WebView(this)
        browser = view
        view.setBackgroundColor(Color.BLACK)
        view.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            allowFileAccess = false
            allowContentAccess = false
            setSupportMultipleWindows(false)
        }
        view.addJavascriptInterface(Bridge(), "TVBridge")
        view.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(web: WebView, request: WebResourceRequest): Boolean {
                val url = request.url
                val allowed = URI(serverUrl)
                return url.scheme != "https" || url.host != allowed.host || url.port != allowed.port
            }
            override fun onReceivedError(web: WebView, request: WebResourceRequest, error: WebResourceError) {
                if (request.isForMainFrame) {
                    AlertDialog.Builder(this@MainActivity).setTitle("Sunucuya bağlanılamadı")
                        .setMessage("HTTPS adresini ve interneti kontrol et. Uyuyan sunucunun açılması biraz sürebilir.\n${error.description}")
                        .setPositiveButton("Tekrar dene") { _, _ -> openTv() }
                        .setNegativeButton("Ayarlar") { _, _ -> showSettings() }.show()
                }
            }
        }
        setContentView(view); view.requestFocus(); view.loadUrl("$serverUrl/tv")
    }
    inner class Bridge {
        @JavascriptInterface fun qr(text: String): String {
            if (text.length > 2048 || !text.startsWith("$serverUrl/#")) return ""
            return try {
                val matrix = MultiFormatWriter().encode(text, BarcodeFormat.QR_CODE, 512, 512, mapOf(EncodeHintType.MARGIN to 3))
                val pixels = IntArray(512 * 512) { i -> if (matrix[i % 512, i / 512]) Color.BLACK else Color.WHITE }
                val bitmap = Bitmap.createBitmap(pixels, 512, 512, Bitmap.Config.ARGB_8888)
                val bytes = ByteArrayOutputStream(); bitmap.compress(Bitmap.CompressFormat.PNG, 100, bytes); bitmap.recycle()
                "data:image/png;base64," + Base64.encodeToString(bytes.toByteArray(), Base64.NO_WRAP)
            } catch (_: Exception) { "" }
        }
        @JavascriptInterface fun settings() { runOnUiThread { showSettings() } }
    }
    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_MENU) { showSettings(); return true }
        return super.onKeyDown(keyCode, event)
    }
    @Deprecated("TV remote back")
    override fun onBackPressed() {
        AlertDialog.Builder(this).setTitle("Yayını kapatıp çık?")
            .setPositiveButton("Çık") { _, _ -> finish() }.setNegativeButton("Devam et", null).show()
    }
    override fun onResume() { super.onResume(); window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); browser?.onResume(); if (paused) browser?.reload(); paused = false }
    override fun onPause() { browser?.evaluateJavascript("window.stopLive && window.stopLive()", null); browser?.onPause(); paused = true; window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON); super.onPause() }
    override fun onDestroy() { destroyBrowser(); super.onDestroy() }
}
