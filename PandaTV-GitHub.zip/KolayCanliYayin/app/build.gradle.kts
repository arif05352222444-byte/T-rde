plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android {
    namespace = "com.kolaycanliyayin.tv"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.kolaycanliyayin.tv"
        minSdk = 26
        targetSdk = 35
        versionCode = (System.getenv("BUILD_NUMBER") ?: "1").toInt()
        versionName = "0.1.0"
        val url = (System.getenv("APP_URL") ?: "").trim().trimEnd('/')
        require(url.isEmpty() || (url.startsWith("https://") && !url.contains('"') && !url.contains('\\') && !url.contains('\n') && !url.contains('\r'))) { "APP_URL geçerli HTTPS adresi olmalı" }
        buildConfigField("String", "DEFAULT_SERVER_URL", "\"$url\"")
    }
    signingConfigs {
        if (!System.getenv("SIGNING_STORE_FILE").isNullOrBlank()) {
            create("production") {
                storeFile = file(System.getenv("SIGNING_STORE_FILE"))
                storePassword = System.getenv("SIGNING_STORE_PASSWORD")
                keyAlias = System.getenv("SIGNING_KEY_ALIAS")
                keyPassword = System.getenv("SIGNING_KEY_PASSWORD")
            }
        }
    }
    buildTypes {
        getByName("debug") { applicationIdSuffix = ".debug"; versionNameSuffix = "-beta" }
        getByName("release") {
            isMinifyEnabled = false
            signingConfig = signingConfigs.findByName("production")
        }
    }
    buildFeatures { buildConfig = true }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies { implementation("com.google.zxing:core:3.5.3") }
