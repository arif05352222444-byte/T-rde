# Panda TV beta — doğrulama durumu

## Çalıştırılıp geçen kontroller

- Node yerleşik test koşucusu: 6 test, 6 başarılı.
- HTTP statik sayfalar/görseller, origin kontrolü, QR odası oluşturma ve eşleştirme akışı.
- Ayrı alıcı/gönderici token’ları, yanlış token reddi, süre sonu, tek kullanımlık katılım.
- TV onayından önce SDP engeli, mesaj rolü ve boyut kontrolleri, kuyruk sınırı.
- Public/STUN/TURN adaylarının reddi; yerel IP/mDNS host adaylarının kabulü.
- Panda logosunun ekran içinde sabit konumu ve tam ekran modunda gizlenmemesi (kaynak kontrolü).
- Kaynak JavaScript sözdizimi kontrolü.
- Retro çerçevenin orta pikselinin gerçekten alfa saydam olması doğrulandı.

## Bu ortamda yapılmayanlar

- Android SDK bulunmadığı için APK derlemesi ve Android lint çalıştırılmadı. Bunları GitHub Actions yapacak.
- Fiziksel iPhone/Android TV ve aynı ağ üzerinde uçtan uca canlı görüntü/ses testi yapılmadı.
- Safari ve Android WebView görsel/etkileşim testi yapılmadı.
- HTTPS sunucusu yayına alınmadı; örnek adresler gerçek dağıtım adresi değildir.

Bu ayrım önemlidir: otomatik testler protokol ve kaynak yapısını doğrular; her cihazda canlı yayının çalıştığını kanıtlamaz. İlk cihaz testi başarısız olursa Actions logu, TV WebView sürümü ve ekrandaki hata gerekir.
