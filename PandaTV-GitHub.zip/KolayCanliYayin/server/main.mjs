import http from 'node:http';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { Rooms } from './rooms.mjs';
export function createApp({ publicUrl = process.env.PUBLIC_URL || '', rooms = new Rooms() } = {}) {
  const origin = publicUrl ? new URL(publicUrl).origin : '';
  const rates = new Map();
  const files = { '/': ['sender.html','text/html'], '/tv': ['tv.html','text/html'],
    '/style.css': ['style.css','text/css'], '/common.mjs': ['common.mjs','text/javascript'],
    '/sender.mjs': ['sender.mjs','text/javascript'], '/tv.mjs': ['tv.mjs','text/javascript'], '/frame.png': ['frame.png','image/png'], '/panda-logo.png': ['panda-logo.png','image/png'] };
  return http.createServer(async (req, res) => {
    const headers = { 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'no-referrer', 'Cache-Control': 'no-store',
      'Permissions-Policy': 'camera=(self), microphone=(self)',
      'Content-Security-Policy': "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; media-src 'self' blob:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; object-src 'none'" };
    const json = (code, value) => { res.writeHead(code, { ...headers, 'Content-Type': 'application/json' }); res.end(JSON.stringify(value)); };
    try {
      const path = new URL(req.url, 'http://local').pathname;
      if (path === '/health' && req.method === 'GET') return json(200, { ok: true });
      if (req.method === 'GET' && files[path]) {
        const [file, type] = files[path]; const body = await readFile(fileURLToPath(new URL('../web/' + file, import.meta.url)));
        res.writeHead(200, { ...headers, 'Content-Type': type }); return res.end(body);
      }
      if (!path.startsWith('/api/') || req.method !== 'POST') return json(404, { error: 'not-found' });
      // In production requests must originate from the configured HTTPS site.
      if (origin && req.headers.origin !== origin) return json(403, { error: 'origin' });
      if (!(req.headers['content-type'] || '').startsWith('application/json')) return json(415, { error: 'json-required' });
      let size = 0; const chunks = [];
      for await (const chunk of req) { size += chunk.length; if (size > 98304) { json(413, { error: 'too-large' }); req.destroy(); return; } chunks.push(chunk); }
      const body = JSON.parse(Buffer.concat(chunks).toString() || '{}');
      if (path === '/api/create') {
        // Proxy forwarding is deliberately not trusted. Global cap also limits resource use.
        const ip = req.socket.remoteAddress; const now = Date.now();
        for (const [key, value] of rates) if (value.until < now) rates.delete(key);
        const rate = rates.get(ip) || { until: now + 60000, count: 0 };
        if (++rate.count > 60) return json(429, { error: 'rate-limit' }); rates.set(ip, rate);
        return json(201, rooms.create());
      }
      const r = rooms.auth(body.id, body.role, req.headers.authorization?.replace(/^Bearer /, ''));
      if (path === '/api/join' && body.role === 'sender') { rooms.join(r); return json(200, { ok: true }); }
      if (path === '/api/signal') { rooms.signal(r, body.role, body.message || {}); return json(200, { ok: true }); }
      if (path === '/api/poll') return json(200, { messages: rooms.poll(r, body.role) });
      if (path === '/api/delete' && body.role === 'receiver') { rooms.rooms.delete(r.id); return json(200, { ok: true }); }
      return json(404, { error: 'not-found' });
    } catch (error) {
      const message = error instanceof SyntaxError ? 'invalid-json' : error.message;
      const statuses = { unauthorized: 401, capacity: 503, 'already-joined': 409, 'queue-full': 429 };
      json(statuses[message] || 400, { error: message });
    }
  });
}
if (process.argv[1] === fileURLToPath(import.meta.url)) {
  if (process.env.NODE_ENV === 'production' && !process.env.PUBLIC_URL) throw Error('PUBLIC_URL HTTPS adresini ayarlayın.');
  if (process.env.PUBLIC_URL && !process.env.PUBLIC_URL.startsWith('https://')) throw Error('PUBLIC_URL HTTPS olmalı.');
  const app = createApp(); app.requestTimeout = 15000; app.headersTimeout = 10000;
  app.listen(Number(process.env.PORT || 3000), '0.0.0.0', () => console.log('Kolay Canlı Yayın sunucusu hazır.'));
}
