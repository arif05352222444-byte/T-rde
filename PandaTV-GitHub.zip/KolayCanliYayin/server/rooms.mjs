import { randomBytes, timingSafeEqual } from 'node:crypto';
const secret = () => randomBytes(24).toString('base64url');
const same = (a, b) => typeof a === 'string' && Buffer.byteLength(a) === Buffer.byteLength(b) && timingSafeEqual(Buffer.from(a), Buffer.from(b));
export class Rooms {
  constructor({ now = Date.now, max = 100 } = {}) { this.now = now; this.max = max; this.rooms = new Map(); }
  sweep() { for (const [id, room] of this.rooms) if (room.expires <= this.now()) this.rooms.delete(id); }
  create() {
    this.sweep(); if (this.rooms.size >= this.max) throw Error('capacity');
    const room = { id: secret(), receiver: secret(), sender: secret(), claimed: false, approved: false, ended: false,
      expires: this.now() + 300000, queues: { sender: [], receiver: [] } };
    this.rooms.set(room.id, room);
    return { id: room.id, receiver: room.receiver, sender: room.sender, expires: room.expires };
  }
  auth(id, role, token) {
    this.sweep(); const r = this.rooms.get(id);
    if (!r || !['sender', 'receiver'].includes(role) || !same(token, r[role])) throw Error('unauthorized');
    return r;
  }
  push(r, role, message) {
    if (r.queues[role].length >= 128) throw Error('queue-full');
    r.queues[role].push(message);
  }
  join(r) {
    if (r.claimed) throw Error('already-joined');
    r.claimed = true; this.push(r, 'receiver', { type: 'join' });
  }
  signal(r, role, message) {
    const { type } = message;
    if (r.ended) throw Error('session-ended');
    if (type === 'accept' && role === 'receiver' && r.claimed && !r.approved) {
      r.approved = true; r.expires = this.now() + 4 * 3600000;
    } else if (type === 'reject' && role === 'receiver') {
      r.expires = this.now() + 10000; r.ended = true;
    } else if (type === 'stop') {
      r.expires = this.now() + 10000; r.ended = true;
    } else if (!r.approved || !['offer', 'answer', 'candidate'].includes(type)) throw Error('not-approved');
    if ((type === 'offer' && role !== 'sender') || (type === 'answer' && role !== 'receiver')) throw Error('wrong-role');
    if (['offer', 'answer'].includes(type) && (typeof message.sdp !== 'string' || message.sdp.length > 80000)) throw Error('invalid-sdp');
    if (type === 'candidate' && (!message.candidate || typeof message.candidate.candidate !== 'string' || message.candidate.candidate.length > 2048)) throw Error('invalid-candidate');
    this.push(r, role === 'sender' ? 'receiver' : 'sender', message);
  }
  poll(r, role) { return r.queues[role].splice(0, 128); }
}
